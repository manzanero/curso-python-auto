class SecureArea(object):

    def __init__(self, driver):
        self.driver = driver

    def btn__logout(self):
        return self.driver.find_element_by_xpath("//*[@id='content']/div/a")

    def assert_page_loaded(self):
        btn__logout = self.btn__logout()
        assert btn__logout.is_displayed()