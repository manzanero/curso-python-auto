from selenium.webdriver.common.keys import Keys


class Portal(object):

    def __init__(self, driver):
        self.driver = driver

    def get(self):
        self.driver.get("https://the-internet.herokuapp.com/login")
        return self

    def tbx__username(self):
        return self.driver.find_element_by_id("username")

    def tbx__password(self):
        return self.driver.find_element_by_id("password")

    def login(self, username, password):
        tbx__username = self.tbx__username()
        tbx__username.clear()
        tbx__username.send_keys(username)

        tbx__password = self.tbx__password()
        tbx__password.clear()
        tbx__password.send_keys(password)

        tbx__password.send_keys(Keys.RETURN)
