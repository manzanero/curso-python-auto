from behave import *

from pageobjects.portal import Portal
from pageobjects.secure_area import SecureArea


@step('estoy en la pagina de login')
def step_impl(context):
    context.driver.get("https://the-internet.herokuapp.com/login")


@step('meto las credenciales correctas')
def step_impl(context):
    page__portal = Portal(context.driver)
    page__portal.login("tomsmith", "SuperSecretPassword!")


@step('accedo al area segura')
def step_impl(context):
    page__secure_area = SecureArea(context.driver)
    page__secure_area.assert_page_loaded()


@step('pulso logout')
def step_impl(context):
    page__secure_area = SecureArea(context.driver)
    page__secure_area.btn__logout().click()


@step('accedo al portal')
def step_impl(context):
    page__portal = Portal(context.driver)
    assert page__portal.tbx__username().is_displayed()
